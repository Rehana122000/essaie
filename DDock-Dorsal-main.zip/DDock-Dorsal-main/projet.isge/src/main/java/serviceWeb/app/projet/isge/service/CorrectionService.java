package serviceWeb.app.projet.isge.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import serviceWeb.app.projet.isge.dto.CorrectionDto;
import serviceWeb.app.projet.isge.entity.CorrectionEntity;
import serviceWeb.app.projet.isge.repository.CorrectionRepository;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
public class CorrectionService  {
    @Autowired
    private CorrectionRepository correctionRepository;

    public List<CorrectionEntity> getAllCorrections() {
        return correctionRepository.findAll();
    }

    public CorrectionEntity getCorrectionById(Long correctionId) {
        return correctionRepository.findById(correctionId)
                .orElseThrow(() -> new RuntimeException("Correction non trouvée"));

    }
    public CorrectionEntity createCorrection(CorrectionDto correctionDto) {

        Long user_id = correctionDto.getUserId();
        LocalDate currentDate = LocalDate.now();
        Optional<CorrectionEntity> existingCorrection = correctionRepository.findByUserIdAndCreatedAt(user_id, currentDate.atStartOfDay());

        if (existingCorrection.isPresent()) {
            throw new RuntimeException("Un utilisateur ne peut insérer qu'une seule correction par jour.");

        }

        CorrectionEntity correctionEntity = new CorrectionEntity();
        correctionEntity.setCorrection(correctionDto.getCorrection());
        correctionEntity.setCreatedAt(LocalDateTime.now());
        correctionEntity.setUserId(correctionDto.getUserId());
         return correctionRepository.save(correctionEntity);
    }

    public CorrectionEntity updateCorrection(Long correctionId, CorrectionDto correctionDto) {
        CorrectionEntity correctionEntity = correctionRepository.findById(correctionId)
                .orElseThrow(() -> new RuntimeException("Correction non trouvée"));

         correctionEntity.setCorrection(correctionDto.getCorrection());
        correctionEntity.setUpdateAt(LocalDateTime.now());


        return correctionRepository.save(correctionEntity);
    }

    public void deleteCorrection(Long correctionId) {
        if (!correctionRepository.existsById(correctionId)) {
            throw new RuntimeException("Correction non trouvée");
        }
        correctionRepository.deleteById(correctionId);
    }



}
