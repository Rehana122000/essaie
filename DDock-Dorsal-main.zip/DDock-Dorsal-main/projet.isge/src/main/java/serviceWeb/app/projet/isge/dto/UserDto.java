package serviceWeb.app.projet.isge.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Data
public class UserDto {
    private long id;
    private String nom;
    private String prenom;
    private String email;
    private String role;
    private String motDePass;
}