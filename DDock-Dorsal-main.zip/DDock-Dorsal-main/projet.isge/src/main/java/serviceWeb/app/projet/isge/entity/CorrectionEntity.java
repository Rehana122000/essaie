package serviceWeb.app.projet.isge.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
@Data
@Entity
@Table (name = "correction")
public class CorrectionEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false)
    private int correction;
    @Column(nullable = false ,updatable = false)
    private Long userId;
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    @Column(name = "update_at")
    private LocalDateTime updateAt;
}
