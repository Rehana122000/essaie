package serviceWeb.app.projet.isge.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import serviceWeb.app.projet.isge.entity.UserEntity;
import serviceWeb.app.projet.isge.service.UserService;

public interface UserRepository extends JpaRepository<UserEntity, Long> {

}
