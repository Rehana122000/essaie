package serviceWeb.app.projet.isge.dto;

import lombok.Data;

import java.time.LocalDateTime;
@Data
public class CorrectionDto {
    private Long id;
    private int correction;
    private LocalDateTime createdAt;
    private LocalDateTime updateAt;
    private Long userId;
}
