package serviceWeb.app.projet.isge.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import serviceWeb.app.projet.isge.entity.CorrectionEntity;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface CorrectionRepository extends JpaRepository<CorrectionEntity, Long> {
    Optional<CorrectionEntity> findByUserIdAndCreatedAt(Long user_id, LocalDateTime createdAt);

}
