package serviceWeb.app.projet.isge.ressource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import serviceWeb.app.projet.isge.dto.CorrectionDto;
import serviceWeb.app.projet.isge.entity.CorrectionEntity;
import serviceWeb.app.projet.isge.repository.CorrectionRepository;
import serviceWeb.app.projet.isge.service.CorrectionService;

import java.util.List;

@RestController
@RequestMapping("/correction")
public class CorrectionRessource {
    @Autowired
    private CorrectionService correctionService;

    @GetMapping("/all")
    public ResponseEntity<List<CorrectionEntity>> getAllCorrections() {
        try {
            List<CorrectionEntity> corrections = correctionService.getAllCorrections();
            return ResponseEntity.ok(corrections);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
    @GetMapping("/{correctionId}")
    public ResponseEntity<CorrectionEntity> getCorrectionById(@PathVariable Long correctionId) {
        try {
            CorrectionEntity correction = correctionService.getCorrectionById(correctionId);
            return ResponseEntity.ok(correction);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @PostMapping("/create")
    public ResponseEntity<CorrectionEntity> createCorrection(@RequestBody CorrectionDto correctionDto) {
        try {
            CorrectionEntity createdCorrection = correctionService.createCorrection(correctionDto);
            return ResponseEntity.ok(createdCorrection);
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @PutMapping("/{correctionId}/update")
    public ResponseEntity<CorrectionEntity> updateCorrection(@PathVariable Long correctionId, @RequestBody CorrectionDto correctionDto) {
        try {
            CorrectionEntity updatedCorrection = correctionService.updateCorrection(correctionId, correctionDto);
            return ResponseEntity.ok(updatedCorrection);
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{correctionId}/delete")
    public ResponseEntity<Void> deleteCorrection(@PathVariable Long correctionId) {
        try {
            correctionService.deleteCorrection(correctionId);
            return ResponseEntity.ok().build();
        } catch (RuntimeException e) {
            return ResponseEntity.notFound().build();
        }
    }
}
