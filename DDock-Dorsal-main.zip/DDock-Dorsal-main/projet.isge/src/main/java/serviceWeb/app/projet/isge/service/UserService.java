package serviceWeb.app.projet.isge.service;

import jakarta.transaction.Transactional;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import serviceWeb.app.projet.isge.dto.CorrectionDto;
import serviceWeb.app.projet.isge.dto.UserDto;
import serviceWeb.app.projet.isge.entity.CorrectionEntity;
import serviceWeb.app.projet.isge.entity.UserEntity;
import serviceWeb.app.projet.isge.repository.UserRepository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private BCryptPasswordEncoder bCryptPasswordEncoder;
    public List<UserEntity> getAllUsers() {
        return userRepository.findAll();
    }

    public UserEntity getUserById(Long userId) {
        return userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("Utilisateur non trouvé"));

    }
    public UserEntity createUser(UserDto userDTO) {
        // Convertir UserDTO en UserService
        UserEntity newUser = convertToEntity(userDTO);
        return userRepository.save(newUser);
    }

    public void deleteUser(Long userId) {

        if (!userRepository.existsById(userId)) {
            throw new RuntimeException("Utilisateur non trouvé");
        }
        userRepository.deleteById(userId);
    }

    public UserEntity updateUser(Long userId, UserDto userDTO) {
        Optional<UserEntity> userOptional = userRepository.findById(userId);
        if (userOptional.isPresent()) {
            UserEntity existingUser = userOptional.get();
            existingUser.setNom(userDTO.getNom());
            existingUser.setPrenom(userDTO.getPrenom());
            existingUser.setEmail(userDTO.getEmail());
            existingUser.setMotDePass(userDTO.getMotDePass());
            return userRepository.save(existingUser);
        }
        else {
            throw new RuntimeException("Utilisateur non trouvé");
        }
    }


    private UserEntity convertToEntity(UserDto userDTO) {
        UserEntity user = new UserEntity();
        user.setNom(userDTO.getNom());
        user.setPrenom(userDTO.getPrenom());
        user.setEmail(userDTO.getEmail());
        user.setRole(userDTO.getRole());
        String hashedPassword = bCryptPasswordEncoder.encode(userDTO.getMotDePass());
        user.setMotDePass(hashedPassword);
        return user;
    }
}


