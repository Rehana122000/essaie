package serviceWeb.app.projet.isge.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity
@Table(name = "utilisateur")
public class UserEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, updatable = false)
    private String nom;
    private String prenom;
    private String email;
    private String role;
    @Column(nullable = false)
    private String motDePass;
    @OneToMany(mappedBy = "userId")
    private List<CorrectionEntity> corrections;
}
